'use client'

import { useEffect, useState, useRef } from 'react'

// ==================== CSS STYLES ====================
const styles = `
:root {
  --primary: #667eea;
  --primary-dark: #5a67d8;
  --primary-light: #7c8ff7;
  --secondary: #764ba2;
  --accent: #f093fb;
  --bg: #f0f2f5;
  --surface: #ffffff;
  --surface2: #f8f9fa;
  --text: #1a202c;
  --text2: #4a5568;
  --text3: #718096;
  --border: #e2e8f0;
  --shadow: 0 2px 15px rgba(0,0,0,0.08);
  --success: #48bb78;
  --warning: #ecc94b;
  --danger: #fc8181;
  --info: #63b3ed;
  --radius: 16px;
  --radius-sm: 10px;
  --radius-xs: 6px;
  --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  --font: 'Segoe UI', Tahoma, Arial, sans-serif;
}

[data-theme="dark"] {
  --bg: #1a202c;
  --surface: #2d3748;
  --surface2: #4a5568;
  --text: #e2e8f0;
  --text2: #a0aec0;
  --text3: #718096;
  --border: #4a5568;
  --shadow: 0 2px 15px rgba(0,0,0,0.3);
}

[data-color="blue"] { --primary: #667eea; --primary-dark: #5a67d8; --primary-light: #7c8ff7; --secondary: #764ba2; --accent: #f093fb; }
[data-color="green"] { --primary: #48bb78; --primary-dark: #38a169; --primary-light: #68d391; --secondary: #2f855a; --accent: #9ae6b4; }
[data-color="purple"] { --primary: #9f7aea; --primary-dark: #805ad5; --primary-light: #b794f4; --secondary: #6b46c1; --accent: #d6bcfa; }
[data-color="red"] { --primary: #fc8181; --primary-dark: #f56565; --primary-light: #feb2b2; --secondary: #c53030; --accent: #fed7d7; }
[data-color="orange"] { --primary: #ed8936; --primary-dark: #dd6b20; --primary-light: #f6ad55; --secondary: #c05621; --accent: #fbd38d; }
[data-color="teal"] { --primary: #38b2ac; --primary-dark: #319795; --primary-light: #4fd1c5; --secondary: #2c7a7b; --accent: #81e6d9; }
[data-color="pink"] { --primary: #ed64a6; --primary-dark: #d53f8c; --primary-light: #f687b3; --secondary: #b83280; --accent: #fed7e2; }
[data-color="cyan"] { --primary: #0bc5ea; --primary-dark: #00b5d8; --primary-light: #22d3ee; --secondary: #0987a0; --accent: #a5f3fc; }
[data-color="indigo"] { --primary: #5c6bc0; --primary-dark: #3949ab; --primary-light: #7986cb; --secondary: #283593; --accent: #c5cae9; }
[data-color="amber"] { --primary: #ffa726; --primary-dark: #fb8c00; --primary-light: #ffb74d; --secondary: #ef6c00; --accent: #ffe0b2; }
[data-color="emerald"] { --primary: #10b981; --primary-dark: #059669; --primary-light: #34d399; --secondary: #047857; --accent: #a7f3d0; }
[data-color="rose"] { --primary: #f43f5e; --primary-dark: #e11d48; --primary-light: #fb7185; --secondary: #be123c; --accent: #fecdd3; }

* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { height: 100%; overflow: hidden; }
body { font-family: var(--font); background: var(--bg); color: var(--text); transition: var(--transition); }

.app { display: flex; height: 100vh; width: 100vw; overflow: hidden; }

.sidebar {
  width: 78px;
  background: linear-gradient(180deg, var(--primary), var(--secondary));
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 12px 0;
  gap: 4px;
  overflow-y: auto;
  z-index: 100;
  transition: var(--transition);
  box-shadow: 2px 0 20px rgba(0,0,0,0.1);
}
.sidebar::-webkit-scrollbar { display: none; }

.logo {
  width: 50px;
  height: 50px;
  background: rgba(255,255,255,0.2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  margin-bottom: 12px;
  cursor: pointer;
  color: #fff;
  transition: var(--transition);
}
.logo:hover { transform: scale(1.1); background: rgba(255,255,255,0.3); }

.nav-item {
  width: 60px;
  height: 60px;
  border-radius: var(--radius-sm);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: rgba(255,255,255,0.7);
  transition: var(--transition);
  font-size: 10px;
  gap: 4px;
  text-align: center;
  position: relative;
}
.nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.2); color: #fff; transform: scale(1.05); }
.nav-item .icon { font-size: 22px; }
.nav-item .lock-icon { position: absolute; top: 2px; right: 2px; font-size: 8px; }
.nav-item .icon { font-size: 22px; }

.main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }

.header {
  height: 64px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  padding: 0 24px;
  gap: 16px;
  box-shadow: var(--shadow);
  z-index: 50;
}
.header h1 { font-size: 20px; color: var(--primary); flex: 1; }
.header-actions { display: flex; gap: 8px; align-items: center; }

.content { flex: 1; overflow-y: auto; padding: 20px; scroll-behavior: smooth; }
.content::-webkit-scrollbar { width: 6px; }
.content::-webkit-scrollbar-thumb { background: var(--primary-light); border-radius: 3px; }

.section { display: none; animation: fadeIn 0.4s ease; }
.section.active { display: block; }

@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
@keyframes slideUp { from { opacity: 0; transform: translateY(100%); } to { opacity: 1; transform: translateY(0); } }

.card { background: var(--surface); border-radius: var(--radius); padding: 20px; box-shadow: var(--shadow); margin-bottom: 16px; transition: var(--transition); }
.card:hover { box-shadow: 0 4px 25px rgba(0,0,0,0.12); }
.card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; flex-wrap: wrap; gap: 8px; }
.card-title { font-size: 18px; font-weight: 700; color: var(--text); }

.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
.stat-card { background: var(--surface); border-radius: var(--radius); padding: 20px; box-shadow: var(--shadow); display: flex; align-items: center; gap: 16px; transition: var(--transition); cursor: pointer; border-right: 4px solid var(--primary); }
.stat-card:hover { transform: translateY(-3px); box-shadow: 0 8px 30px rgba(0,0,0,0.15); }
.stat-card .stat-icon { width: 50px; height: 50px; border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; font-size: 24px; }
.stat-card .stat-icon.blue { background: rgba(102,126,234,0.15); color: var(--primary); }
.stat-card .stat-icon.green { background: rgba(72,187,120,0.15); color: var(--success); }
.stat-card .stat-icon.orange { background: rgba(237,137,54,0.15); color: #ed8936; }
.stat-card .stat-icon.pink { background: rgba(237,100,166,0.15); color: #ed64a6; }
.stat-card .stat-info h3 { font-size: 28px; font-weight: 700; color: var(--text); }
.stat-card .stat-info p { font-size: 13px; color: var(--text3); }

.form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 16px; }
.form-group { display: flex; flex-direction: column; gap: 6px; }
.form-group label { font-size: 13px; font-weight: 600; color: var(--text2); }
.form-group input, .form-group select, .form-group textarea {
  padding: 10px 14px;
  border: 2px solid var(--border);
  border-radius: var(--radius-xs);
  font-size: 14px;
  font-family: var(--font);
  background: var(--surface);
  color: var(--text);
  transition: var(--transition);
  outline: none;
}
.form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(102,126,234,0.15); }
.form-group textarea { min-height: 80px; resize: vertical; }

.btn { padding: 10px 20px; border: none; border-radius: var(--radius-xs); font-size: 14px; font-weight: 600; cursor: pointer; transition: var(--transition); display: inline-flex; align-items: center; gap: 8px; font-family: var(--font); }
.btn:active { transform: scale(0.96); }
.btn-primary { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: #fff; }
.btn-primary:hover { opacity: 0.9; box-shadow: 0 4px 15px rgba(102,126,234,0.4); }
.btn-success { background: var(--success); color: #fff; }
.btn-danger { background: var(--danger); color: #fff; }
.btn-warning { background: var(--warning); color: #333; }
.btn-outline { background: transparent; border: 2px solid var(--primary); color: var(--primary); }
.btn-outline:hover { background: var(--primary); color: #fff; }
.btn-sm { padding: 6px 14px; font-size: 12px; }
.btn-group { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 12px; }

.table-wrapper { overflow-x: auto; border-radius: var(--radius-sm); border: 1px solid var(--border); }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
thead { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: #fff; }
th, td { padding: 12px 16px; text-align: right; white-space: nowrap; }
th { font-weight: 600; font-size: 12px; }
tbody tr { border-bottom: 1px solid var(--border); transition: var(--transition); }
tbody tr:hover { background: rgba(102,126,234,0.05); }
tbody tr:nth-child(even) { background: var(--surface2); }

.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); backdrop-filter: blur(4px); z-index: 1000; display: none; align-items: center; justify-content: center; padding: 20px; }
.modal-overlay.show { display: flex; }
.modal { background: var(--surface); border-radius: var(--radius); width: 100%; max-width: 600px; max-height: 90vh; overflow-y: auto; animation: slideUp 0.3s ease; }
.modal-header { padding: 20px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; background: var(--surface); z-index: 1; border-radius: var(--radius) var(--radius) 0 0; }
.modal-header h2 { font-size: 18px; color: var(--primary); }
.modal-close { width: 36px; height: 36px; border-radius: 50%; border: none; background: var(--surface2); color: var(--text); cursor: pointer; font-size: 18px; display: flex; align-items: center; justify-content: center; transition: var(--transition); }
.modal-close:hover { background: var(--danger); color: #fff; }
.modal-body { padding: 20px; }
.modal-footer { padding: 16px 20px; border-top: 1px solid var(--border); display: flex; gap: 8px; justify-content: flex-end; }

.toast-container { position: fixed; top: 80px; left: 20px; z-index: 2000; display: flex; flex-direction: column; gap: 8px; }
.toast { padding: 12px 20px; border-radius: var(--radius-xs); color: #fff; font-size: 14px; font-weight: 500; animation: slideUp 0.3s ease; display: flex; align-items: center; gap: 8px; min-width: 280px; box-shadow: 0 4px 20px rgba(0,0,0,0.2); }
.toast.success { background: var(--success); }
.toast.error { background: var(--danger); }
.toast.info { background: var(--info); }
.toast.warning { background: var(--warning); color: #333; }

.chip { display: inline-flex; align-items: center; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; gap: 4px; }
.chip-primary { background: rgba(102,126,234,0.15); color: var(--primary); }
.chip-success { background: rgba(72,187,120,0.15); color: var(--success); }
.chip-danger { background: rgba(252,129,129,0.15); color: #e53e3e; }

.session-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 10px; }
.session-option { padding: 12px; border: 2px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; transition: var(--transition); display: flex; align-items: center; justify-content: space-between; }
.session-option:hover { border-color: var(--primary-light); }
.session-option.selected { border-color: var(--primary); background: rgba(102,126,234,0.08); }
.session-option .session-name { font-weight: 600; font-size: 13px; }
.session-option .session-price { color: var(--primary); font-weight: 700; font-size: 14px; }

.color-grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; }
.color-option { width: 100%; aspect-ratio: 1; border-radius: var(--radius-sm); cursor: pointer; transition: var(--transition); border: 3px solid transparent; position: relative; }
.color-option:hover { transform: scale(1.1); }
.color-option.active { border-color: var(--text); transform: scale(1.1); }
.color-option.active::after { content: '✓'; position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px; font-weight: 700; text-shadow: 0 1px 2px rgba(0,0,0,0.3); }

.sync-status { display: flex; align-items: center; gap: 6px; font-size: 12px; padding: 4px 10px; border-radius: 20px; }
.sync-status.connected { background: rgba(72,187,120,0.15); color: var(--success); }
.sync-status.disconnected { background: rgba(252,129,129,0.15); color: #e53e3e; }

.password-screen { position: fixed; inset: 0; background: linear-gradient(135deg, var(--primary), var(--secondary)); z-index: 900; display: none; align-items: center; justify-content: center; }
.password-screen.show { display: flex; }
.password-box { background: var(--surface); border-radius: var(--radius); padding: 40px; text-align: center; width: 320px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
.password-box h2 { margin-bottom: 8px; color: var(--primary); }
.password-box p { color: var(--text3); margin-bottom: 20px; font-size: 14px; }
.password-box input { width: 100%; padding: 14px; border: 2px solid var(--border); border-radius: var(--radius-xs); font-size: 18px; text-align: center; letter-spacing: 8px; outline: none; font-family: var(--font); }
.password-box input:focus { border-color: var(--primary); }
.password-box .btn { width: 100%; margin-top: 12px; justify-content: center; }

.toggle-switch { position: relative; width: 50px; height: 26px; background: var(--border); border-radius: 13px; cursor: pointer; transition: var(--transition); }
.toggle-switch.active { background: var(--success); }
.toggle-switch::after { content: ''; position: absolute; width: 22px; height: 22px; background: #fff; border-radius: 50%; top: 2px; left: 2px; transition: var(--transition); }
.toggle-switch.active::after { left: 26px; }

.section-protection { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--border); }
.section-protection span { font-size: 14px; }

.sync-info { background: var(--surface2); border-radius: var(--radius-sm); padding: 12px; margin-bottom: 12px; }
.sync-info p { font-size: 13px; color: var(--text2); margin-bottom: 4px; }
.sync-info code { background: var(--surface); padding: 2px 6px; border-radius: 4px; font-size: 12px; }

.backup-history { max-height: 200px; overflow-y: auto; }
.backup-item { display: flex; justify-content: space-between; align-items: center; padding: 8px; border-bottom: 1px solid var(--border); font-size: 13px; }

.delete-options { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin-top: 12px; }
.delete-option { padding: 12px; border: 2px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; transition: var(--transition); text-align: center; }
.delete-option:hover { border-color: var(--danger); background: rgba(252,129,129,0.1); }

@media (max-width: 768px) {
  .sidebar { width: 60px; padding: 8px 0; }
  .nav-item { width: 48px; height: 48px; font-size: 8px; }
  .nav-item .icon { font-size: 18px; }
  .header { padding: 0 12px; height: 56px; }
  .header h1 { font-size: 16px; }
  .content { padding: 12px; }
  .form-grid { grid-template-columns: 1fr; }
  .stats-grid { grid-template-columns: repeat(2, 1fr); }
  .stat-card { padding: 12px; }
  .stat-card .stat-info h3 { font-size: 20px; }
  .modal { max-width: 95vw; }
  .color-grid { grid-template-columns: repeat(4, 1fr); }
  .delete-options { grid-template-columns: 1fr; }
}
`

// ==================== MAIN COMPONENT ====================
export default function Home() {
  const [mounted, setMounted] = useState(false)
  const [currentSection, setCurrentSection] = useState('center')
  const [showPassword, setShowPassword] = useState(false)
  const [pendingSection, setPendingSection] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [modalTitle, setModalTitle] = useState('')
  const [modalBody, setModalBody] = useState('')
  const [toasts, setToasts] = useState([])
  const [darkMode, setDarkMode] = useState(false)
  const [color, setColor] = useState('blue')
  const [password, setPassword] = useState('2137')
  const [passwordInput, setPasswordInput] = useState('')
  const [currentPasswordInput, setCurrentPasswordInput] = useState('')
  const [newPasswordInput, setNewPasswordInput] = useState('')
  
  // Sync P2P
  const [syncConnected, setSyncConnected] = useState(false)
  const [deviceId, setDeviceId] = useState('')
  const syncChannelRef = useRef(null)
  
  // Backup
  const [lastBackup, setLastBackup] = useState(null)
  const [autoBackup, setAutoBackup] = useState(true)
  const [backupHistory, setBackupHistory] = useState([])
  const fileInputRef = useRef(null)
  
  // Section Protection
  const [sectionProtection, setSectionProtection] = useState({
    doctors: true,
    files: true,
    reports: true,
    settings: true,
    laser: false,
    assistant: false
  })
  
  // Data states
  const [patients, setPatients] = useState([])
  const [doctors, setDoctors] = useState([])
  const [appointments, setAppointments] = useState([])
  const [expenses, setExpenses] = useState([])
  const [laserSessions, setLaserSessions] = useState([])
  const [sessions, setSessions] = useState([
    { id: 1, name: 'فراكشنال ليزر', price: 500 },
    { id: 2, name: 'كى تون', price: 400 },
    { id: 3, name: 'تقشير بارد', price: 350 },
    { id: 4, name: 'بلازما', price: 500 },
    { id: 5, name: 'فيلر', price: 1500 },
    { id: 6, name: 'بوتكس', price: 1200 },
  ])
  
  // Form states
  const [patientForm, setPatientForm] = useState({
    name: '', age: '', address: '', phone: '', visitType: '', fee: '', notes: '', nextVisit: ''
  })
  const [selectedSessions, setSelectedSessions] = useState([])
  
  const COLORS = [
    { name: 'blue', label: 'أزرق', bg: '#667eea' },
    { name: 'green', label: 'أخضر', bg: '#48bb78' },
    { name: 'purple', label: 'بنفسجي', bg: '#9f7aea' },
    { name: 'red', label: 'أحمر', bg: '#fc8181' },
    { name: 'orange', label: 'برتقالي', bg: '#ed8936' },
    { name: 'teal', label: 'تيل', bg: '#38b2ac' },
    { name: 'pink', label: 'وردي', bg: '#ed64a6' },
    { name: 'cyan', label: 'سماوي', bg: '#0bc5ea' },
    { name: 'indigo', label: 'نيلي', bg: '#5c6bc0' },
    { name: 'amber', label: 'عنبري', bg: '#ffa726' },
    { name: 'emerald', label: 'زمردي', bg: '#10b981' },
    { name: 'rose', label: 'روز', bg: '#f43f5e' }
  ]

  // Initialize
  useEffect(() => {
    setMounted(true)
    
    // Generate or load device ID
    let savedDeviceId = localStorage.getItem('deviceId')
    if (!savedDeviceId) {
      savedDeviceId = 'DC-' + Math.random().toString(36).substr(2, 9).toUpperCase()
      localStorage.setItem('deviceId', savedDeviceId)
    }
    setDeviceId(savedDeviceId)
    
    // Load all data from localStorage
    const loadData = () => {
      const savedPatients = localStorage.getItem('patients')
      const savedDoctors = localStorage.getItem('doctors')
      const savedAppointments = localStorage.getItem('appointments')
      const savedExpenses = localStorage.getItem('expenses')
      const savedLaserSessions = localStorage.getItem('laserSessions')
      const savedDarkMode = localStorage.getItem('darkMode')
      const savedColor = localStorage.getItem('appColor')
      const savedPassword = localStorage.getItem('appPassword')
      const savedLastBackup = localStorage.getItem('lastBackup')
      const savedAutoBackup = localStorage.getItem('autoBackup')
      const savedBackupHistory = localStorage.getItem('backupHistory')
      const savedSectionProtection = localStorage.getItem('sectionProtection')
      
      if (savedPatients) setPatients(JSON.parse(savedPatients))
      if (savedDoctors) setDoctors(JSON.parse(savedDoctors))
      if (savedAppointments) setAppointments(JSON.parse(savedAppointments))
      if (savedExpenses) setExpenses(JSON.parse(savedExpenses))
      if (savedLaserSessions) setLaserSessions(JSON.parse(savedLaserSessions))
      if (savedDarkMode === 'dark') setDarkMode(true)
      if (savedColor) setColor(savedColor)
      if (savedPassword) setPassword(savedPassword)
      if (savedLastBackup) setLastBackup(new Date(savedLastBackup))
      if (savedAutoBackup !== null) setAutoBackup(savedAutoBackup === 'true')
      if (savedBackupHistory) setBackupHistory(JSON.parse(savedBackupHistory))
      if (savedSectionProtection) setSectionProtection(JSON.parse(savedSectionProtection))
    }
    
    loadData()
  }, [])

  // Save data to localStorage
  useEffect(() => {
    if (mounted) {
      localStorage.setItem('patients', JSON.stringify(patients))
      localStorage.setItem('doctors', JSON.stringify(doctors))
      localStorage.setItem('appointments', JSON.stringify(appointments))
      localStorage.setItem('expenses', JSON.stringify(expenses))
      localStorage.setItem('laserSessions', JSON.stringify(laserSessions))
      localStorage.setItem('sectionProtection', JSON.stringify(sectionProtection))
      
      // Broadcast sync if connected
      if (syncChannelRef.current) {
        syncChannelRef.current.postMessage({
          type: 'DATA_UPDATE',
          deviceId,
          data: { patients, doctors, appointments, expenses, laserSessions }
        })
      }
    }
  }, [patients, doctors, appointments, expenses, laserSessions, mounted, sectionProtection])

  // Dark mode
  useEffect(() => {
    if (mounted) {
      localStorage.setItem('darkMode', darkMode ? 'dark' : '')
      document.documentElement.dataset.theme = darkMode ? 'dark' : ''
    }
  }, [darkMode, mounted])

  // Color
  useEffect(() => {
    if (mounted) {
      localStorage.setItem('appColor', color)
      document.documentElement.dataset.color = color
    }
  }, [color, mounted])

  // Auto backup every 24 hours
  useEffect(() => {
    if (!mounted || !autoBackup) return
    
    const checkBackup = () => {
      const now = new Date()
      const lastBackupTime = lastBackup ? new Date(lastBackup).getTime() : 0
      const hoursSinceBackup = (now.getTime() - lastBackupTime) / (1000 * 60 * 60)
      
      if (hoursSinceBackup >= 24) {
        autoBackupData()
      }
    }
    
    const interval = setInterval(checkBackup, 60000) // Check every minute
    checkBackup() // Check immediately
    
    return () => clearInterval(interval)
  }, [mounted, autoBackup, lastBackup])

  const autoBackupData = () => {
    const data = { patients, doctors, appointments, expenses, laserSessions, sessions }
    const backupEntry = {
      date: new Date().toISOString(),
      type: 'تلقائي',
      size: JSON.stringify(data).length
    }
    setBackupHistory(prev => [backupEntry, ...prev.slice(0, 9)])
    localStorage.setItem('backupHistory', JSON.stringify([backupEntry, ...backupHistory.slice(0, 9)]))
    localStorage.setItem('lastBackup', new Date().toISOString())
    setLastBackup(new Date())
    toast('✅ تم النسخ الاحتياطي التلقائي', 'success')
  }

  const toast = (msg, type = 'success') => {
    const id = Date.now()
    setToasts(prev => [...prev, { id, msg, type }])
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3500)
  }

  const navigateTo = (section) => {
    if (sectionProtection[section]) {
      setPendingSection(section)
      setShowPassword(true)
      setPasswordInput('')
    } else {
      setCurrentSection(section)
    }
  }

  const checkPassword = () => {
    if (passwordInput === password) {
      setShowPassword(false)
      setCurrentSection(pendingSection)
    } else {
      toast('كلمة السر غير صحيحة', 'error')
      setPasswordInput('')
    }
  }

  const changePassword = () => {
    if (currentPasswordInput !== password) {
      toast('كلمة السر الحالية غير صحيحة', 'error')
      return
    }
    if (newPasswordInput.length < 4) {
      toast('كلمة السر يجب أن تكون 4 أحرف على الأقل', 'warning')
      return
    }
    setPassword(newPasswordInput)
    localStorage.setItem('appPassword', newPasswordInput)
    setCurrentPasswordInput('')
    setNewPasswordInput('')
    toast('تم تغيير كلمة السر بنجاح', 'success')
  }

  const toggleSectionProtection = (section) => {
    setSectionProtection(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }

  // ==================== SYNC P2P ====================
  const startSync = () => {
    try {
      syncChannelRef.current = new BroadcastChannel('derma-center-sync')
      
      syncChannelRef.current.onmessage = (event) => {
        const { type, deviceId: senderId, data } = event.data
        
        if (senderId === deviceId) return
        
        if (type === 'DATA_UPDATE') {
          if (data.patients) setPatients(data.patients)
          if (data.doctors) setDoctors(data.doctors)
          if (data.appointments) setAppointments(data.appointments)
          if (data.expenses) setExpenses(data.expenses)
          if (data.laserSessions) setLaserSessions(data.laserSessions)
          toast('🔄 تم استلام تحديثات من جهاز آخر', 'info')
        }
        
        if (type === 'SYNC_REQUEST') {
          // Send current data to requesting device
          syncChannelRef.current.postMessage({
            type: 'DATA_UPDATE',
            deviceId,
            data: { patients, doctors, appointments, expenses, laserSessions }
          })
        }
      }
      
      // Request sync from other devices
      syncChannelRef.current.postMessage({
        type: 'SYNC_REQUEST',
        deviceId
      })
      
      setSyncConnected(true)
      toast('🔗 تم بدء المزامنة', 'success')
    } catch (error) {
      toast('خطأ في بدء المزامنة', 'error')
    }
  }

  const stopSync = () => {
    if (syncChannelRef.current) {
      syncChannelRef.current.close()
      syncChannelRef.current = null
    }
    setSyncConnected(false)
    toast('تم إيقاف المزامنة', 'info')
  }

  // ==================== BACKUP ====================
  const manualBackup = () => {
    const data = { patients, doctors, appointments, expenses, laserSessions, sessions }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `derma-center-backup-${new Date().toISOString().split('T')[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
    
    const backupEntry = {
      date: new Date().toISOString(),
      type: 'يدوي',
      size: blob.size
    }
    setBackupHistory(prev => [backupEntry, ...prev.slice(0, 9)])
    localStorage.setItem('backupHistory', JSON.stringify([backupEntry, ...backupHistory.slice(0, 9)]))
    localStorage.setItem('lastBackup', new Date().toISOString())
    setLastBackup(new Date())
    
    toast('📥 تم إنشاء النسخة الاحتياطية', 'success')
  }

  const restoreBackup = (event) => {
    const file = event.target.files[0]
    if (!file) return
    
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result)
        
        if (!confirm('⚠️ سيتم استبدال جميع البيانات الحالية. هل أنت متأكد؟')) return
        
        if (data.patients) setPatients(data.patients)
        if (data.doctors) setDoctors(data.doctors)
        if (data.appointments) setAppointments(data.appointments)
        if (data.expenses) setExpenses(data.expenses)
        if (data.laserSessions) setLaserSessions(data.laserSessions)
        if (data.sessions) setSessions(data.sessions)
        
        toast('📤 تم استعادة النسخة الاحتياطية بنجاح', 'success')
      } catch (err) {
        toast('خطأ في قراءة الملف', 'error')
      }
    }
    reader.readAsText(file)
    event.target.value = ''
  }

  // ==================== DELETE DATA ====================
  const clearSpecificData = (dataType) => {
    const messages = {
      patients: 'المرضى',
      doctors: 'الأطباء',
      appointments: 'المواعيد',
      expenses: 'المصروفات',
      laserSessions: 'جلسات الليزر',
      sessions: 'أنواع الجلسات'
    }
    
    if (!confirm(`⚠️ هل أنت متأكد من حذف ${messages[dataType]}؟`)) return
    
    switch(dataType) {
      case 'patients': setPatients([]); break
      case 'doctors': setDoctors([]); break
      case 'appointments': setAppointments([]); break
      case 'expenses': setExpenses([]); break
      case 'laserSessions': setLaserSessions([]); break
      case 'sessions': setSessions([]); break
    }
    
    toast(`تم حذف ${messages[dataType]}`, 'warning')
  }

  const clearAllData = () => {
    if (!confirm('⚠️ تحذير! سيتم حذف جميع البيانات نهائياً. هل أنت متأكد؟')) return
    if (!confirm('هذا الإجراء لا يمكن التراجع عنه. هل أنت متأكد تماماً؟')) return
    
    setPatients([])
    setDoctors([])
    setAppointments([])
    setExpenses([])
    setLaserSessions([])
    setSessions([])
    
    toast('تم حذف جميع البيانات', 'warning')
  }

  // ==================== PATIENTS ====================
  const savePatient = () => {
    if (!patientForm.name) {
      toast('أدخل اسم المريض', 'warning')
      return
    }
    if (!patientForm.visitType) {
      toast('اختر نوع الزيارة', 'warning')
      return
    }
    
    let totalAmount = parseFloat(patientForm.fee) || 0
    if (patientForm.visitType === 'جلسة') {
      totalAmount = selectedSessions.reduce((s, ss) => s + ss.price, 0)
    }
    if (patientForm.visitType === 'كشف + جلسة') {
      totalAmount = (parseFloat(patientForm.fee) || 0) + selectedSessions.reduce((s, ss) => s + ss.price, 0)
    }
    
    const newPatient = {
      id: Date.now(),
      ...patientForm,
      sessions: selectedSessions,
      totalAmount,
      createdAt: new Date().toISOString()
    }
    
    setPatients(prev => [newPatient, ...prev])
    
    if (patientForm.nextVisit) {
      setAppointments(prev => [{
        id: Date.now(),
        patientId: newPatient.id,
        patientName: newPatient.name,
        phone: newPatient.phone,
        date: newPatient.nextVisit,
        type: newPatient.visitType,
        status: 'قادم'
      }, ...prev])
    }
    
    toast('✅ تم حفظ بيانات المريض بنجاح')
    setPatientForm({ name: '', age: '', address: '', phone: '', visitType: '', fee: '', notes: '', nextVisit: '' })
    setSelectedSessions([])
  }

  const deletePatient = (id) => {
    if (confirm('هل أنت متأكد من حذف هذا المريض؟')) {
      setPatients(prev => prev.filter(p => p.id !== id))
      toast('تم الحذف', 'info')
    }
  }

  const sendWhatsApp = (phone, name) => {
    if (!phone) {
      toast('لا يوجد رقم هاتف', 'warning')
      return
    }
    const msg = encodeURIComponent(`مرحباً ${name}،\nنتمنى لك الشفاء العاجل.\nمركز الجلدية والليزر`)
    window.open(`https://wa.me/${phone.replace(/\D/g, '')}?text=${msg}`, '_blank')
  }

  const addExpense = () => {
    setModalTitle('📉 إضافة مصروف')
    setModalBody(`
      <div class="form-grid">
        <div class="form-group"><label>التاريخ</label><input type="date" id="expDate" value="${new Date().toISOString().split('T')[0]}"></div>
        <div class="form-group"><label>البند</label><input type="text" id="expItem"></div>
        <div class="form-group"><label>المبلغ</label><input type="number" id="expAmount"></div>
      </div>
      <div class="form-group" style="margin-top:12px"><label>ملاحظات</label><textarea id="expNotes"></textarea></div>
    `)
    setShowModal(true)
  }

  const saveExpense = () => {
    const expense = {
      id: Date.now(),
      date: document.getElementById('expDate')?.value || new Date().toISOString().split('T')[0],
      item: document.getElementById('expItem')?.value || '',
      amount: parseFloat(document.getElementById('expAmount')?.value) || 0,
      notes: document.getElementById('expNotes')?.value || ''
    }
    setExpenses(prev => [expense, ...prev])
    setShowModal(false)
    toast('تم الحفظ')
  }

  if (!mounted) return null

  // Calculate stats
  const today = new Date().toISOString().split('T')[0]
  const todayVisits = patients.filter(p => p.createdAt?.startsWith(today))
  const totalRevenue = patients.reduce((s, p) => s + (parseFloat(p.totalAmount) || 0), 0)
  const totalExpenses = expenses.reduce((s, e) => s + (parseFloat(e.amount) || 0), 0)
  const netProfit = totalRevenue - totalExpenses
  const upcomingAppointments = appointments.filter(a => new Date(a.date) >= new Date()).slice(0, 5)

  const titles = {
    center: '🏠 لوحة التحكم',
    assistant: '👨‍💼 المساعد',
    doctors: '👨‍⚕️ الأطباء',
    laser: '✨ ليزر إزالة الشعر',
    files: '📁 الملفات',
    search: '🔍 البحث المتقدم',
    reports: '📊 التقارير',
    settings: '⚙️ الإعدادات'
  }

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: styles }} />
      
      <div className="app">
        {/* Sidebar */}
        <nav className="sidebar">
          <div className="logo" onClick={() => setCurrentSection('center')}>🏥</div>
          
          {[
            { id: 'center', icon: '🏠', label: 'المركز' },
            { id: 'assistant', icon: '👨‍💼', label: 'المساعد' },
            { id: 'doctors', icon: '👨‍⚕️', label: 'الأطباء' },
            { id: 'laser', icon: '✨', label: 'الليزر' },
            { id: 'files', icon: '📁', label: 'الملفات' },
            { id: 'search', icon: '🔍', label: 'البحث' },
            { id: 'reports', icon: '📊', label: 'التقارير' },
            { id: 'settings', icon: '⚙️', label: 'الإعدادات' },
          ].map(item => (
            <div
              key={item.id}
              className={`nav-item ${currentSection === item.id ? 'active' : ''}`}
              onClick={() => navigateTo(item.id)}
            >
              <span className="icon">{item.icon}</span>
              <span>{item.label}</span>
              {sectionProtection[item.id] && <span className="lock-icon">🔒</span>}
            </div>
          ))}
        </nav>

        <div className="main">
          {/* Header */}
          <header className="header">
            <h1>{titles[currentSection]}</h1>
            <div className="header-actions">
              <div className={`sync-status ${syncConnected ? 'connected' : 'disconnected'}`}>
                <span>●</span> <span>{syncConnected ? 'متزامن' : 'غير متصل'}</span>
              </div>
              <button className="btn btn-sm btn-outline" onClick={() => setDarkMode(!darkMode)}>
                {darkMode ? '☀️' : '🌙'}
              </button>
            </div>
          </header>

          {/* Content */}
          <div className="content">
            {/* CENTER SECTION */}
            {currentSection === 'center' && (
              <div className="section active">
                <div className="stats-grid">
                  <div className="stat-card">
                    <div className="stat-icon blue">👥</div>
                    <div className="stat-info"><h3>{patients.length}</h3><p>إجمالي المرضى</p></div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-icon green">📅</div>
                    <div className="stat-info"><h3>{todayVisits.length}</h3><p>زيارات اليوم</p></div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-icon orange">💰</div>
                    <div className="stat-info"><h3>{totalRevenue.toLocaleString()} ج.م</h3><p>إجمالي الإيرادات</p></div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-icon pink">📉</div>
                    <div className="stat-info"><h3>{totalExpenses.toLocaleString()} ج.م</h3><p>إجمالي المصروفات</p></div>
                  </div>
                </div>

                <div className="card">
                  <div className="card-header">
                    <span className="card-title">📅 زيارات اليوم</span>
                    <button className="btn btn-sm btn-primary" onClick={() => setCurrentSection('assistant')}>+ إضافة مريض</button>
                  </div>
                  <div className="table-wrapper">
                    <table>
                      <thead>
                        <tr><th>#</th><th>اسم المريض</th><th>نوع الزيارة</th><th>الجلسة</th><th>المبلغ</th><th>الحالة</th></tr>
                      </thead>
                      <tbody>
                        {todayVisits.length ? todayVisits.map((p, i) => (
                          <tr key={p.id}>
                            <td>{i + 1}</td>
                            <td>{p.name}</td>
                            <td><span className="chip chip-primary">{p.visitType}</span></td>
                            <td>{p.sessions?.map(s => s.name).join(', ') || '-'}</td>
                            <td>{p.totalAmount} ج.م</td>
                            <td><span className="chip chip-success">✓</span></td>
                          </tr>
                        )) : (
                          <tr><td colSpan="6" style={{ textAlign: 'center', color: 'var(--text3)' }}>لا توجد زيارات اليوم</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="card">
                  <div className="card-header"><span className="card-title">📞 المواعيد القادمة</span></div>
                  {upcomingAppointments.length ? upcomingAppointments.map(a => (
                    <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '10px', borderBottom: '1px solid var(--border)' }}>
                      <span style={{ fontSize: '20px' }}>📅</span>
                      <div style={{ flex: 1 }}><strong>{a.patientName}</strong><br/><span style={{ color: 'var(--text3)', fontSize: '12px' }}>{new Date(a.date).toLocaleString('ar-EG')}</span></div>
                      <span className="chip chip-primary">{a.type}</span>
                      <button className="btn btn-sm btn-success" onClick={() => sendWhatsApp(a.phone, a.patientName)}>📱</button>
                    </div>
                  )) : (
                    <p style={{ textAlign: 'center', color: 'var(--text3)', padding: '20px' }}>لا توجد مواعيد قادمة</p>
                  )}
                </div>
              </div>
            )}

            {/* ASSISTANT SECTION */}
            {currentSection === 'assistant' && (
              <div className="section active">
                <div className="card">
                  <div className="card-header"><span className="card-title">📝 تسجيل مريض جديد</span></div>
                  <div className="form-grid">
                    <div className="form-group">
                      <label>الاسم الكامل</label>
                      <input type="text" placeholder="أدخل اسم المريض" value={patientForm.name} onChange={e => setPatientForm({...patientForm, name: e.target.value})} />
                    </div>
                    <div className="form-group">
                      <label>السن</label>
                      <input type="number" placeholder="السن" value={patientForm.age} onChange={e => setPatientForm({...patientForm, age: e.target.value})} />
                    </div>
                    <div className="form-group">
                      <label>العنوان</label>
                      <input type="text" placeholder="العنوان" value={patientForm.address} onChange={e => setPatientForm({...patientForm, address: e.target.value})} />
                    </div>
                    <div className="form-group">
                      <label>رقم الهاتف</label>
                      <input type="tel" placeholder="رقم الهاتف" value={patientForm.phone} onChange={e => setPatientForm({...patientForm, phone: e.target.value})} />
                    </div>
                    <div className="form-group">
                      <label>نوع الزيارة</label>
                      <select value={patientForm.visitType} onChange={e => setPatientForm({...patientForm, visitType: e.target.value})}>
                        <option value="">اختر نوع الزيارة</option>
                        <option value="كشف">كشف</option>
                        <option value="إعادة">إعادة</option>
                        <option value="جلسة">جلسة</option>
                        <option value="كشف + جلسة">كشف + جلسة</option>
                      </select>
                    </div>
                    <div className="form-group">
                      <label>قيمة الكشف (جنيه)</label>
                      <input type="number" placeholder="0" value={patientForm.fee} onChange={e => setPatientForm({...patientForm, fee: e.target.value})} />
                    </div>
                  </div>

                  {(patientForm.visitType === 'جلسة' || patientForm.visitType === 'كشف + جلسة') && (
                    <div style={{ marginTop: '16px' }}>
                      <label style={{ fontSize: '14px', fontWeight: '600', marginBottom: '10px', display: 'block' }}>اختر الجلسات:</label>
                      <div className="session-grid">
                        {sessions.map(s => (
                          <div
                            key={s.id}
                            className={`session-option ${selectedSessions.find(ss => ss.id === s.id) ? 'selected' : ''}`}
                            onClick={() => {
                              setSelectedSessions(prev =>
                                prev.find(ss => ss.id === s.id)
                                  ? prev.filter(ss => ss.id !== s.id)
                                  : [...prev, s]
                              )
                            }}
                          >
                            <span className="session-name">{s.name}</span>
                            <span className="session-price">{s.price} ج.م</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="form-group" style={{ marginTop: '16px' }}>
                    <label>ملاحظات</label>
                    <textarea placeholder="ملاحظات إضافية..." value={patientForm.notes} onChange={e => setPatientForm({...patientForm, notes: e.target.value})}></textarea>
                  </div>

                  <div className="form-group" style={{ marginTop: '12px' }}>
                    <label>📅 الموعد القادم</label>
                    <input type="datetime-local" value={patientForm.nextVisit} onChange={e => setPatientForm({...patientForm, nextVisit: e.target.value})} />
                  </div>

                  <div className="btn-group">
                    <button className="btn btn-primary" onClick={savePatient}>💾 حفظ البيانات</button>
                    <button className="btn btn-outline" onClick={() => { setPatientForm({ name: '', age: '', address: '', phone: '', visitType: '', fee: '', notes: '', nextVisit: '' }); setSelectedSessions([]) }}>🗑️ مسح</button>
                  </div>
                </div>

                <div className="card">
                  <div className="card-header"><span className="card-title">📋 سجل المرضى ({patients.length})</span></div>
                  <div className="table-wrapper">
                    <table>
                      <thead>
                        <tr><th>#</th><th>الاسم</th><th>السن</th><th>الهاتف</th><th>نوع الزيارة</th><th>التاريخ</th><th>المبلغ</th><th>إجراء</th></tr>
                      </thead>
                      <tbody>
                        {patients.length ? patients.slice(0, 20).map((p, i) => (
                          <tr key={p.id}>
                            <td>{i + 1}</td>
                            <td>{p.name}</td>
                            <td>{p.age || '-'}</td>
                            <td>{p.phone || '-'}</td>
                            <td><span className="chip chip-primary">{p.visitType}</span></td>
                            <td>{new Date(p.createdAt).toLocaleDateString('ar-EG')}</td>
                            <td>{p.totalAmount} ج.م</td>
                            <td>
                              <button className="btn btn-sm btn-danger" onClick={() => deletePatient(p.id)}>🗑️</button>
                              <button className="btn btn-sm btn-success" onClick={() => sendWhatsApp(p.phone, p.name)}>📱</button>
                            </td>
                          </tr>
                        )) : (
                          <tr><td colSpan="8" style={{ textAlign: 'center', color: 'var(--text3)' }}>لا توجد بيانات</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* DOCTORS SECTION */}
            {currentSection === 'doctors' && (
              <div className="section active">
                <div className="card">
                  <div className="card-header">
                    <span className="card-title">👨‍⚕️ قائمة الأطباء</span>
                    <button className="btn btn-sm btn-primary" onClick={() => {
                      setModalTitle('👨‍⚕️ إضافة طبيب')
                      setModalBody(`
                        <div class="form-grid">
                          <div class="form-group"><label>الاسم</label><input type="text" id="docName"></div>
                          <div class="form-group"><label>التخصص</label><input type="text" id="docSpecialty"></div>
                          <div class="form-group"><label>الهاتف</label><input type="tel" id="docPhone"></div>
                          <div class="form-group"><label>النسبة %</label><input type="number" id="docPercentage" value="0"></div>
                        </div>
                      `)
                      setShowModal(true)
                    }}>+ إضافة طبيب</button>
                  </div>
                  <div className="table-wrapper">
                    <table>
                      <thead><tr><th>الاسم</th><th>التخصص</th><th>الهاتف</th><th>النسبة %</th><th>إجراء</th></tr></thead>
                      <tbody>
                        {doctors.length ? doctors.map(d => (
                          <tr key={d.id}>
                            <td>{d.name}</td>
                            <td>{d.specialty || '-'}</td>
                            <td>{d.phone || '-'}</td>
                            <td>{d.percentage || 0}%</td>
                            <td>
                              <button className="btn btn-sm btn-danger" onClick={() => setDoctors(prev => prev.filter(doc => doc.id !== d.id))}>🗑️</button>
                            </td>
                          </tr>
                        )) : (
                          <tr><td colSpan="5" style={{ textAlign: 'center', color: 'var(--text3)' }}>لا يوجد أطباء</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="card">
                  <div className="card-header"><span className="card-title">💰 نسب الأطباء</span></div>
                  {doctors.length ? doctors.map(d => (
                    <div key={d.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', borderBottom: '1px solid var(--border)' }}>
                      <span><strong>{d.name}</strong> ({d.percentage}%)</span>
                      <span style={{ color: 'var(--primary)', fontWeight: '700' }}>{((totalRevenue * (d.percentage || 0)) / 100).toLocaleString()} ج.م</span>
                    </div>
                  )) : (
                    <p style={{ color: 'var(--text3)' }}>لا يوجد أطباء مسجلين</p>
                  )}
                </div>
              </div>
            )}

            {/* LASER SECTION */}
            {currentSection === 'laser' && (
              <div className="section active">
                <div className="card">
                  <div className="card-header"><span className="card-title">✨ سجل جلسات الليزر</span></div>
                  <div className="table-wrapper">
                    <table>
                      <thead><tr><th>المريض</th><th>المنطقة</th><th>رقم الجلسة</th><th>التاريخ</th><th>إجراء</th></tr></thead>
                      <tbody>
                        {laserSessions.length ? laserSessions.map(s => (
                          <tr key={s.id}>
                            <td>{s.patientName}</td>
                            <td>{s.area}</td>
                            <td>{s.sessionNum}</td>
                            <td>{new Date(s.createdAt).toLocaleDateString('ar-EG')}</td>
                            <td><button className="btn btn-sm btn-danger" onClick={() => setLaserSessions(prev => prev.filter(ls => ls.id !== s.id))}>🗑️</button></td>
                          </tr>
                        )) : (
                          <tr><td colSpan="5" style={{ textAlign: 'center', color: 'var(--text3)' }}>لا توجد جلسات</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* FILES SECTION */}
            {currentSection === 'files' && (
              <div className="section active">
                <div className="card">
                  <div className="card-header"><span className="card-title">📁 إدارة الملفات</span></div>
                  <p style={{ color: 'var(--text3)' }}>قسم إدارة الملفات - يمكنك رفع وتنظيم ملفات المرضى</p>
                </div>
              </div>
            )}

            {/* SEARCH SECTION */}
            {currentSection === 'search' && (
              <div className="section active">
                <div className="card">
                  <div className="card-header"><span className="card-title">🔍 نتائج البحث ({patients.length})</span></div>
                  <div className="table-wrapper">
                    <table>
                      <thead><tr><th>#</th><th>الاسم</th><th>الهاتف</th><th>نوع الزيارة</th><th>التاريخ</th><th>المبلغ</th><th>إجراء</th></tr></thead>
                      <tbody>
                        {patients.length ? patients.map((p, i) => (
                          <tr key={p.id}>
                            <td>{i + 1}</td>
                            <td>{p.name}</td>
                            <td>{p.phone || '-'}</td>
                            <td><span className="chip chip-primary">{p.visitType}</span></td>
                            <td>{new Date(p.createdAt).toLocaleDateString('ar-EG')}</td>
                            <td>{p.totalAmount} ج.م</td>
                            <td><button className="btn btn-sm btn-success" onClick={() => sendWhatsApp(p.phone, p.name)}>📱</button></td>
                          </tr>
                        )) : (
                          <tr><td colSpan="7" style={{ textAlign: 'center', color: 'var(--text3)' }}>لا توجد نتائج</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* REPORTS SECTION */}
            {currentSection === 'reports' && (
              <div className="section active">
                <div className="stats-grid">
                  <div className="stat-card">
                    <div className="stat-icon green">💰</div>
                    <div className="stat-info"><h3>{totalRevenue.toLocaleString()} ج.م</h3><p>إجمالي الإيرادات</p></div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-icon pink">📉</div>
                    <div className="stat-info"><h3>{totalExpenses.toLocaleString()} ج.م</h3><p>إجمالي المصروفات</p></div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-icon blue">📊</div>
                    <div className="stat-info"><h3>{netProfit.toLocaleString()} ج.م</h3><p>صافي الربح</p></div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-icon orange">👥</div>
                    <div className="stat-info"><h3>{patients.length}</h3><p>عدد المرضى</p></div>
                  </div>
                </div>

                <div className="card">
                  <div className="card-header">
                    <span className="card-title">📉 سجل المصروفات</span>
                    <button className="btn btn-sm btn-primary" onClick={addExpense}>+ مصروف جديد</button>
                  </div>
                  <div className="table-wrapper">
                    <table>
                      <thead><tr><th>التاريخ</th><th>البند</th><th>المبلغ</th><th>ملاحظات</th><th>إجراء</th></tr></thead>
                      <tbody>
                        {expenses.length ? expenses.slice(0, 20).map(e => (
                          <tr key={e.id}>
                            <td>{new Date(e.date).toLocaleDateString('ar-EG')}</td>
                            <td>{e.item}</td>
                            <td>{e.amount} ج.م</td>
                            <td>{e.notes || '-'}</td>
                            <td><button className="btn btn-sm btn-danger" onClick={() => setExpenses(prev => prev.filter(ex => ex.id !== e.id))}>🗑️</button></td>
                          </tr>
                        )) : (
                          <tr><td colSpan="5" style={{ textAlign: 'center', color: 'var(--text3)' }}>لا توجد مصروفات</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* SETTINGS SECTION */}
            {currentSection === 'settings' && (
              <div className="section active">
                {/* المظهر */}
                <div className="card">
                  <div className="card-header"><span className="card-title">🎨 المظهر والألوان</span></div>
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ fontWeight: '600', marginBottom: '10px', display: 'block' }}>لون التطبيق:</label>
                    <div className="color-grid">
                      {COLORS.map(c => (
                        <div
                          key={c.name}
                          className={`color-option ${color === c.name ? 'active' : ''}`}
                          style={{ background: c.bg }}
                          onClick={() => setColor(c.name)}
                          title={c.label}
                        />
                      ))}
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <label style={{ fontWeight: '600' }}>الوضع الليلي:</label>
                    <div className={`toggle-switch ${darkMode ? 'active' : ''}`} onClick={() => setDarkMode(!darkMode)}></div>
                  </div>
                </div>

                {/* الحماية */}
                <div className="card">
                  <div className="card-header"><span className="card-title">🔒 نظام الحماية</span></div>
                  
                  <div className="form-grid" style={{ marginBottom: '16px' }}>
                    <div className="form-group">
                      <label>كلمة السر الحالية</label>
                      <input type="password" placeholder="••••" value={currentPasswordInput} onChange={e => setCurrentPasswordInput(e.target.value)} />
                    </div>
                    <div className="form-group">
                      <label>كلمة السر الجديدة</label>
                      <input type="password" placeholder="••••" value={newPasswordInput} onChange={e => setNewPasswordInput(e.target.value)} />
                    </div>
                  </div>
                  <button className="btn btn-primary" onClick={changePassword}>🔑 تغيير كلمة السر</button>
                  
                  <div style={{ marginTop: '20px' }}>
                    <label style={{ fontWeight: '600', marginBottom: '12px', display: 'block' }}>حماية الأقسام:</label>
                    {[
                      { id: 'doctors', name: '👨‍⚕️ الأطباء' },
                      { id: 'files', name: '📁 الملفات' },
                      { id: 'reports', name: '📊 التقارير' },
                      { id: 'settings', name: '⚙️ الإعدادات' },
                      { id: 'laser', name: '✨ الليزر' },
                      { id: 'assistant', name: '👨‍💼 المساعد' },
                    ].map(section => (
                      <div key={section.id} className="section-protection">
                        <span>{section.name}</span>
                        <div 
                          className={`toggle-switch ${sectionProtection[section.id] ? 'active' : ''}`}
                          onClick={() => toggleSectionProtection(section.id)}
                        ></div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* المزامنة */}
                <div className="card">
                  <div className="card-header"><span className="card-title">🔄 المزامنة P2P</span></div>
                  
                  <div className="sync-info">
                    <p><strong>معرف الجهاز:</strong> <code>{deviceId}</code></p>
                    <p><strong>الحالة:</strong> {syncConnected ? '🟢 متصل' : '🔴 غير متصل'}</p>
                  </div>
                  
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <div className={`sync-status ${syncConnected ? 'connected' : 'disconnected'}`}>
                      <span>●</span> <span>{syncConnected ? 'متزامن' : 'غير متصل'}</span>
                    </div>
                    {syncConnected ? (
                      <button className="btn btn-sm btn-danger" onClick={stopSync}>⏹️ إيقاف المزامنة</button>
                    ) : (
                      <button className="btn btn-sm btn-primary" onClick={startSync}>🔗 بدء المزامنة</button>
                    )}
                  </div>
                  
                  <p style={{ marginTop: '12px', fontSize: '13px', color: 'var(--text3)' }}>
                    💡 المزامنة تعمل بين الأجهزة على نفس المتصفح. افتح التطبيق على جهازين واضغط "بدء المزامنة" على كليهما.
                  </p>
                </div>

                {/* النسخ الاحتياطي */}
                <div className="card">
                  <div className="card-header"><span className="card-title">💾 النسخ الاحتياطي</span></div>
                  
                  <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '16px' }}>
                    <button className="btn btn-primary" onClick={manualBackup}>📥 نسخ احتياطي يدوي</button>
                    <button className="btn btn-outline" onClick={() => fileInputRef.current?.click()}>📤 استيراد نسخة</button>
                    <input ref={fileInputRef} type="file" accept=".json" style={{ display: 'none' }} onChange={restoreBackup} />
                  </div>
                  
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
                    <label style={{ fontWeight: '600' }}>نسخ تلقائي كل 24 ساعة:</label>
                    <div className={`toggle-switch ${autoBackup ? 'active' : ''}`} onClick={() => {
                      setAutoBackup(!autoBackup)
                      localStorage.setItem('autoBackup', (!autoBackup).toString())
                    }}></div>
                  </div>
                  
                  <p style={{ fontSize: '13px', color: 'var(--text3)' }}>
                    {lastBackup ? `آخر نسخة: ${new Date(lastBackup).toLocaleString('ar-EG')}` : 'لم يتم إنشاء نسخة بعد'}
                  </p>
                  
                  {backupHistory.length > 0 && (
                    <div style={{ marginTop: '16px' }}>
                      <label style={{ fontWeight: '600', marginBottom: '8px', display: 'block' }}>📜 سجل النسخ:</label>
                      <div className="backup-history">
                        {backupHistory.map((b, i) => (
                          <div key={i} className="backup-item">
                            <span>{new Date(b.date).toLocaleString('ar-EG')}</span>
                            <span className="chip chip-primary">{b.type}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* حذف البيانات */}
                <div className="card">
                  <div className="card-header"><span className="card-title">⚠️ حذف البيانات</span></div>
                  
                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ fontWeight: '600', marginBottom: '8px', display: 'block' }}>🗑️ حذف بيانات محددة:</label>
                    <div className="delete-options">
                      <div className="delete-option" onClick={() => clearSpecificData('patients')}>
                        <span>👥</span><br/><span>المرضى</span>
                      </div>
                      <div className="delete-option" onClick={() => clearSpecificData('doctors')}>
                        <span>👨‍⚕️</span><br/><span>الأطباء</span>
                      </div>
                      <div className="delete-option" onClick={() => clearSpecificData('appointments')}>
                        <span>📅</span><br/><span>المواعيد</span>
                      </div>
                      <div className="delete-option" onClick={() => clearSpecificData('expenses')}>
                        <span>📉</span><br/><span>المصروفات</span>
                      </div>
                      <div className="delete-option" onClick={() => clearSpecificData('laserSessions')}>
                        <span>✨</span><br/><span>جلسات الليزر</span>
                      </div>
                      <div className="delete-option" onClick={() => clearSpecificData('sessions')}>
                        <span>💉</span><br/><span>أنواع الجلسات</span>
                      </div>
                    </div>
                  </div>
                  
                  <button className="btn btn-danger" onClick={clearAllData}>💣 حذف كل البيانات</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Password Screen */}
      {showPassword && (
        <div className="password-screen show">
          <div className="password-box">
            <h2>🔒 قسم محمي</h2>
            <p>أدخل كلمة السر للمتابعة</p>
            <input
              type="password"
              maxLength={10}
              placeholder="••••"
              value={passwordInput}
              onChange={e => setPasswordInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && checkPassword()}
              autoFocus
            />
            <button className="btn btn-primary" onClick={checkPassword}>دخول</button>
            <button className="btn btn-outline" style={{ marginTop: '8px' }} onClick={() => setShowPassword(false)}>إلغاء</button>
          </div>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay show" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <h2>{modalTitle}</h2>
              <button className="modal-close" onClick={() => setShowModal(false)}>✕</button>
            </div>
            <div className="modal-body" dangerouslySetInnerHTML={{ __html: modalBody }} />
            <div className="modal-footer">
              <button className="btn btn-primary" onClick={() => {
                if (modalTitle.includes('طبيب')) {
                  const name = document.getElementById('docName')?.value
                  const specialty = document.getElementById('docSpecialty')?.value
                  const phone = document.getElementById('docPhone')?.value
                  const percentage = parseFloat(document.getElementById('docPercentage')?.value) || 0
                  if (name) {
                    setDoctors(prev => [...prev, { id: Date.now(), name, specialty, phone, percentage }])
                    toast('تم إضافة الطبيب')
                  }
                } else if (modalTitle.includes('مصروف')) {
                  saveExpense()
                }
                setShowModal(false)
              }}>💾 حفظ</button>
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* Toasts */}
      <div className="toast-container">
        {toasts.map(t => (
          <div key={t.id} className={`toast ${t.type}`}>
            {t.type === 'success' ? '✅' : t.type === 'error' ? '❌' : t.type === 'warning' ? '⚠️' : 'ℹ️'} {t.msg}
          </div>
        ))}
      </div>
    </>
  )
}
